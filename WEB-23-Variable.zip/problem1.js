
let super_hero = "batman";


console.log(super_hero);